import streamlit as st
import requests

st.title("🌾 Smart Farming MCP")

area_id = st.text_input(
    "Enter Farm ID"
)

if st.button("Scan Farm"):

    response = requests.get(
        "http://127.0.0.1:8000/analyze-farm",
        params={"area_id": area_id}
    )

    st.json(response.json())