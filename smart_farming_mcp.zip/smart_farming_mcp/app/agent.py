from tools.drone_scan import scan_farm
from tools.crop_health import analyze_crop
from tools.pest_detection import detect_pests
from tools.soil_analyzer import analyze_soil
from tools.irrigation import irrigation_plan
from tools.fertilizer import fertilizer_suggestion


def run_farm_analysis(area_id):

    drone_data = scan_farm(area_id)

    sensor_data = drone_data["sensor_data"]

    crop_result = analyze_crop(sensor_data)

    soil_result = analyze_soil(sensor_data)

    pest_result = detect_pests(sensor_data)

    irrigation_result = irrigation_plan(
        soil_result
    )

    fertilizer_result = fertilizer_suggestion(
        soil_result
    )

    return {
        "area_id": area_id,
        "drone_scan": drone_data,
        "crop_health": crop_result,
        "soil_analysis": soil_result,
        "pest_detection": pest_result,
        "irrigation": irrigation_result,
        "fertilizer": fertilizer_result
    }