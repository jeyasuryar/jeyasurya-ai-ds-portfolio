from fastapi import FastAPI
from app.agent import run_farm_analysis

app = FastAPI(
    title="Smart Farming MCP"
)


@app.get("/")
def home():
    return {
        "message":
        "Smart Farming MCP Running"
    }


@app.get("/analyze-farm")
def analyze_farm(area_id: str):

    result = run_farm_analysis(area_id)

    return result