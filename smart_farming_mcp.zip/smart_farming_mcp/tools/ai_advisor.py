def farm_advisor(results):

    crop = results["crop_health"]["crop_status"]

    pest = results["pest_detection"]["pest_risk"]

    irrigation = results["irrigation"]["action"]

    fertilizer = results["fertilizer"]["fertilizer"]

    advice = f"""
Crop Health: {crop}

Pest Risk: {pest}

Irrigation Advice:
{irrigation}

Recommended Fertilizer:
{fertilizer}

Overall Recommendation:
Monitor the field regularly and follow the irrigation schedule.
"""

    return advice