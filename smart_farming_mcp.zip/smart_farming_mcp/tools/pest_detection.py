import random

def detect_pests(sensor_data):

    risk = random.choice(
        ["Low", "Medium", "High"]
    )

    return {
        "pest_risk": risk
    }