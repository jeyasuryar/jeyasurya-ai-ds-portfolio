import google.generativeai as genai
import os
from dotenv import load_dotenv

load_dotenv()

genai.configure(
    api_key=os.getenv("GEMINI_API_KEY")
)

model = genai.GenerativeModel("gemini-2.5-flash")


def generate_advice(farm_data):

   prompt = f"""
Analyze this farm data:

{farm_data}

Give farming recommendations in less than 500 words.
"""
   response = model.generate_content(prompt)
   return response.text