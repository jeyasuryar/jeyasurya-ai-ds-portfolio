import csv
from datetime import datetime


def save_scan(sensor_data):

    with open(
        "data/farm_data.csv",
        "a",
        newline=""
    ) as file:

        writer = csv.writer(file)

        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            sensor_data["temperature"],
            sensor_data["humidity"],
            sensor_data["soil_moisture"]
        ])