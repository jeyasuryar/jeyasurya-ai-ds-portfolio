def fertilizer_suggestion(soil_data):

    if soil_data["nitrogen"] == "Low":
        fertilizer = "NPK 10-26-26"
    else:
        fertilizer = "Organic Compost"

    return {
        "fertilizer": fertilizer
    }