def irrigation_plan(soil_data):

    moisture = soil_data["moisture_level"]

    if moisture < 30:
        action = "Irrigate Immediately"
    else:
        action = "No Irrigation Needed"

    return {
        "action": action
    }