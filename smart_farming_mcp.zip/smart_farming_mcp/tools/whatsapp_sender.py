from twilio.rest import Client

ACCOUNT_SID = "AC553e4259688b4db6b22ba6f8b83837cb"
AUTH_TOKEN = "2b2de97d2fad48d4240888a024f4dce2"

client = Client(ACCOUNT_SID, AUTH_TOKEN)

def send_whatsapp(message_text):
    message_text = message_text[:1500]

    message = client.messages.create(
        body=message_text,
        from_="whatsapp:+14155238886",
        to="whatsapp:+916374513208"
    )

    return message.sid