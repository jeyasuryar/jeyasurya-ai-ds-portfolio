import requests

def get_weather(city):

    url = "https://wttr.in/{}?format=j1".format(city)

    response = requests.get(url)

    data = response.json()

    current = data["current_condition"][0]

    return {
        "temperature": current["temp_C"],
        "humidity": current["humidity"],
        "weather": current["weatherDesc"][0]["value"]
    }