def analyze_crop(sensor_data):

    moisture = sensor_data["soil_moisture"]

    if moisture < 20:
        status = "Poor"

    elif moisture < 40:
        status = "Moderate"

    else:
        status = "Healthy"

    return {
        "crop_status": status
    }