from PIL import Image
import google.generativeai as genai
import os

genai.configure(
    api_key=os.getenv("GEMINI_API_KEY")
)

model = genai.GenerativeModel("gemini-1.5-flash")


def detect_crop_disease(image_path):

    image = Image.open(image_path)

    prompt = """
    Analyze this crop image.

    Provide:

    1. Crop Name
    2. Disease Name
    3. Severity (Low/Medium/High)
    4. Symptoms
    5. Treatment Recommendation

    Return farmer-friendly advice.
    """

    response = model.generate_content(
        [prompt, image]
    )

    return response.text