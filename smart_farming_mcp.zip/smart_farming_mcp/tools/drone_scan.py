import random

def scan_farm(area_id):
    return {
        "area_id": area_id,
        "sensor_data": {
            "temperature": random.randint(25, 40),
            "humidity": random.randint(40, 90),
            "soil_moisture": random.randint(10, 60)
        }
    }