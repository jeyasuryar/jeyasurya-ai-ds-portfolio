from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer
)

from reportlab.lib.styles import getSampleStyleSheet


def create_pdf(data):

    filename = "farm_report.pdf"

    pdf = SimpleDocTemplate(filename)

    styles = getSampleStyleSheet()

    content = []

    content.append(
        Paragraph(
            "🌾 Smart Farming Report",
            styles["Title"]
        )
    )

    content.append(Spacer(1, 20))

    content.append(
        Paragraph(
            f"Farm ID: {data['area_id']}",
            styles["BodyText"]
        )
    )

    content.append(
        Paragraph(
            f"Crop Health: {data['crop_health']['crop_status']}",
            styles["BodyText"]
        )
    )

    content.append(
        Paragraph(
            f"Pest Risk: {data['pest_detection']['pest_risk']}",
            styles["BodyText"]
        )
    )

    content.append(
        Paragraph(
            f"Irrigation: {data['irrigation']['action']}",
            styles["BodyText"]
        )
    )

    content.append(
        Paragraph(
            f"Fertilizer: {data['fertilizer']['fertilizer']}",
            styles["BodyText"]
        )
    )

    if "gemini_advice" in data:

        content.append(Spacer(1, 20))

        content.append(
            Paragraph(
                "AI Advisor",
                styles["Heading2"]
            )
        )

        content.append(
            Paragraph(
                data["gemini_advice"],
                styles["BodyText"]
            )
        )

    pdf.build(content)

    return filename