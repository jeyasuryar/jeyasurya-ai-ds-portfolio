def analyze_soil(sensor_data):

    moisture = sensor_data["soil_moisture"]

    if moisture < 30:
        nitrogen = "Low"
    else:
        nitrogen = "Normal"

    return {
        "moisture_level": moisture,
        "nitrogen": nitrogen
    }