async function getAdvice() {

    let crop =
    document.getElementById("crop").value;

    let city =
    document.getElementById("city").value;

    let response =
    await fetch(
    `http://127.0.0.1:8000/crop-advice?crop=${crop}&city=${city}`
    );

    let data = await response.json();

    document.getElementById("weather").innerText =
    JSON.stringify(data.weather_data, null, 2);

    document.getElementById("cropinfo").innerText =
    JSON.stringify(data.crop_data, null, 2);

    document.getElementById("advice").innerText =
    data.ai_advice;
}