from agents.crop_agent import crop_agent
from agents.weather_agent import weather_agent
from agents.rag_agent import search_pdf
from agents.ai_agent import ai_advice

def agriculture_supervisor(crop, city):

    crop_data = crop_agent(crop)

    weather_data = weather_agent(city)

    pdf_data = search_pdf(crop)

    info = f"""
    Crop Data: {crop_data}

    Weather Data: {weather_data}

    PDF Data: {pdf_data}
    """

    advice = ai_advice(info)

    return {
        "crop_data": crop_data,
        "weather_data": weather_data,
        "pdf_data": pdf_data,
        "ai_advice": advice
    }