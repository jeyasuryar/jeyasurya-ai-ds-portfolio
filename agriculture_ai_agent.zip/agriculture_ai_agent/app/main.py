from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.supervisor import agriculture_supervisor

app = FastAPI()

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def home():
    return {"message": "Agriculture AI Agent Running"}

@app.get("/crop-advice")
def crop_advice(crop: str, city: str):
    return agriculture_supervisor(crop, city)