# app/routes.py

from fastapi import APIRouter
from agents.supervisor import supervisor

router = APIRouter()

@router.get("/agriculture")
def agriculture(city: str):

    result = supervisor(city)

    return result