import pandas as pd

df = pd.read_csv("data/crops.csv")

def crop_agent(crop):

    row = df[df["crop"].str.lower() == crop.lower()]

    if row.empty:
        return {"message": "Crop not found"}

    return {
        "water": row["water"].values[0],
        "fertilizer": row["fertilizer"].values[0]
    }