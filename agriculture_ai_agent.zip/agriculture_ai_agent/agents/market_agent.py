def market_agent():

    return {
        "Rice": 45,
        "Wheat": 32,
        "Sugarcane": 38
    }