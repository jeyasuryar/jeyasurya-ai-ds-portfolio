from pypdf import PdfReader

def search_pdf(question):

    reader = PdfReader(
        "data/Rice_Farming_Guide.pdf"
    )

    text = ""

    for page in reader.pages:
        text += page.extract_text()

    return text[:2000]