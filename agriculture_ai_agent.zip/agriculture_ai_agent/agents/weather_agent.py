import requests

def weather_agent(city):

    url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid=81f1cfecd9885e7aebb11cc46a7ca2d3&units=metric"

    data = requests.get(url).json()

    if data.get("cod") != 200:
        return {
            "error": "City not found"
        }

    return {
        "temperature": data["main"]["temp"],
        "humidity": data["main"]["humidity"],
        "weather": data["weather"][0]["description"]
    }