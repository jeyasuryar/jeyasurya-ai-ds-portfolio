from groq import Groq

client = Groq(
    api_key="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"
)

def ai_advice(info):

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {
                "role": "user",
                "content": f"Give farming advice based on this information:\n{info}"
            }
        ]
    )

    return response.choices[0].message.content