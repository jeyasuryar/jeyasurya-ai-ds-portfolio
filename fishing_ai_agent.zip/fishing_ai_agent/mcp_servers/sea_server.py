from mcp.server.fastmcp import FastMCP

mcp = FastMCP("SeaServer")

@mcp.tool()
def sea_condition(location: str):

    return {
        "wave_height": "1.2m",
        "tide": "Low",
        "sea_temperature": "28C",
        "recommendation": "Safe for fishing"
    }

mcp.run()