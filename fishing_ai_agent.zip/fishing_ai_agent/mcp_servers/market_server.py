from mcp.server.fastmcp import FastMCP
import pandas as pd

mcp = FastMCP("MarketServer")

@mcp.tool()
def fish_price(fish_name: str):

    df = pd.read_csv("data/fish_prices.csv")

    result = df[df["fish"] == fish_name]

    if result.empty:
        return "Price not available"

    return result.iloc[0]["price"]

mcp.run()