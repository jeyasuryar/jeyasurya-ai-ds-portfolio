def weather_agent(city):
    return {
        "temp": 34,
        "humidity": 75,
        "wind": 5
    }

def sea_agent(city):
    return {
        "wave_height": 1.2,
        "tide": "Medium"
    }

def market_agent():
    return {
        "Tuna": 450,
        "Seer Fish": 700
    }

def supervisor_agent(city):

    weather = weather_agent(city)

    sea = sea_agent(city)

    market = market_agent()

    if weather["wind"] > 15:
        advice = "Avoid fishing"

    else:
        advice = "Good fishing conditions"

    return {
        "city": city,
        "weather": weather,
        "sea": sea,
        "market": market,
        "advice": advice
    }