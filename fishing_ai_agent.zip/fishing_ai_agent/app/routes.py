from fastapi import APIRouter
from app.services import supervisor_agent

router = APIRouter()

@router.get("/fishing-advice")
def fishing(city: str):

    return supervisor_agent(city)